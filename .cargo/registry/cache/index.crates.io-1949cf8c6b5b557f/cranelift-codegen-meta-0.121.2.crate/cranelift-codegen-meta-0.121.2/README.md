This crate contains the metaprogram used by cranelift-codegen. It's not
useful on its own.
