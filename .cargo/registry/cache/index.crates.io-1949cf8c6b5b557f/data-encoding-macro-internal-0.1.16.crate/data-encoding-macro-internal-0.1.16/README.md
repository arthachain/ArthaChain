Do **not** use this library. Use [data-encoding-macro] instead.

This library is for internal use by data-encoding-macro because procedural
macros require a separate crate.

[data-encoding-macro]: https://crates.io/crates/data-encoding-macro
