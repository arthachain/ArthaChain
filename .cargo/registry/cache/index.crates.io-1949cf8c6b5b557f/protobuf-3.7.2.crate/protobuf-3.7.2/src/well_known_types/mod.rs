// This file is generated. Do not edit
// @generated
//! Generated code for "well known types"
//!
//! [This document](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf) describes these types.

#![allow(unused_attributes)]
#![cfg_attr(rustfmt, rustfmt::skip)]

pub mod any;
pub mod api;
pub mod duration;
pub mod empty;
pub mod field_mask;
pub mod source_context;
pub mod struct_;
pub mod timestamp;
pub mod type_;
pub mod wrappers;
