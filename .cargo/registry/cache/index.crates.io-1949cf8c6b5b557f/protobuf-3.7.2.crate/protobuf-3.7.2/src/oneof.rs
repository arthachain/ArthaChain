/// Trait implemented by all oneof types in generated code.
pub trait Oneof {}
