// Automatically generated mod.rs
pub mod proto;
