// @generated

pub mod proto_model;
