<!-- cargo-sync-readme start -->

# Supporting code for protobuf crates

Code in this crate is used in protobuf crates like `protobuf` or `protobuf-parse`.
None of code in this crate has public API.

<!-- cargo-sync-readme end -->
