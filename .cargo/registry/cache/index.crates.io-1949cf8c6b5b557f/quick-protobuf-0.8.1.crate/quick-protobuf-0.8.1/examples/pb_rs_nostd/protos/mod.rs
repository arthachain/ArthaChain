// Automatically generated mod.rs
pub mod no_std;
