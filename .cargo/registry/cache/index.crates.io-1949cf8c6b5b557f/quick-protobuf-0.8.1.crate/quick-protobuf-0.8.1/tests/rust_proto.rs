extern crate quick_protobuf;

mod packed_primitives;
mod rust_protobuf;
