# Security Policy

Please refer to the [Bytecode Alliance security policy](https://bytecodealliance.org/security) for details on how to report security issues in Cranelift, our disclosure policy, and how to receive notifications about security issues.
