// Re-export ZKP utilities from utils module
pub use crate::utils::zkp::*; 